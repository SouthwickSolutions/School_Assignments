package com.bignerdranch.android.photogallery;

import android.support.v4.app.Fragment;

public class PhotoGalleryActivity extends SingleFragmentActivity {

    //returns an instance of PhotoGalleryFragment
    @Override
    protected Fragment createFragment(){
        return PhotoGalleryFragment.newInstance();
    }
}
