package com.bignerdranch.android.photogallery;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.util.Log;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

//has a single generic argument, <T>. Your ThumbnailDownloader’s user, PhotoGalleryFragment in this
//case, will need to use some object to identify each download and to determine which UI element to
//update with the image once it is downloaded. Rather than locking the user into a specific type of
//object as the identifier, using a generic makes the implementation more flexible.
public class ThumbnailDownloader<T> extends HandlerThread {

    private static final String TAG = "ThumbnailDownloader";
    private static final int MESSAGE_DOWNLOAD = 0; //used to identify messages as download requests

    private boolean mHasQuit = false;
    private Handler mRequestHandler; //will store a reference to the Handler responsible for queuing
    //download requests as messages onto the ThumbnailDownloader background thread. Will also be in
    //charge of processing download request messages when they are pulled off the queue

    private ConcurrentMap<T, String> mRequestMap = new ConcurrentHashMap<>(); //a thread-safe
    //version of HashMap. Here, using a download request's identifying object of type <T> as a key,
    //you can store and retrieve the URL associated with a particular request

    private Handler mResponseHandler;
    private ThumbnailDownloadListener<T> mThumbnailDownloadListener;

    //will eventually be called when an image has been fully downloaded and is ready to be added to
    //the UI. Using this listener delegates the responsibility of what to do with the downloaded
    //image to a class other than ThumbnailDownloader. Doing so separates the downloading task from
    //the UI updating task
    public interface ThumbnailDownloadListener<T>{
        void onThumbnailDownloaded(T target, Bitmap thumbnail);
    }

    public void setmThumbnailDownloadListener(ThumbnailDownloadListener<T> listener){
        mThumbnailDownloadListener = listener;
    }

    public ThumbnailDownloader(Handler responseHandler){
        super(TAG);
        mResponseHandler = responseHandler;
    }

    public ThumbnailDownloader(){
        super(TAG);
    }


    @Override
    protected void onLooperPrepared(){
        mRequestHandler = new Handler(){
            @Override
            public void handleMessage(Message msg){
                if(msg.what == MESSAGE_DOWNLOAD){
                    T target = (T) msg.obj;
                    Log.i(TAG, "Got a request for URL: " + mRequestMap.get(target));
                    handleRequest(target);
                }
            }
        };
    }

    @Override
    public boolean quit(){
        mHasQuit = true;
        return super.quit();
    }

    //method expects an object of type T to use as the identifier for the download and a String
    //containing the URL to download. This is the method you will have PhotoAdapter call in its
    //onBindViewHolder(…) implementation.
    public void queueThumbnail(T target, String url){
        Log.i(TAG, "Got a URL: " + url);

        if(url == null){
            mRequestMap.remove(target);
        }else{
            mRequestMap.put(target, url);
            mRequestHandler.obtainMessage(MESSAGE_DOWNLOAD, target).sendToTarget(); //obtain a message directly from mRequestHandler, which automatically sets the new Message object's target field to mRequestHandler
        }
    }

    public void clearQueue(){
        mRequestHandler.removeMessages(MESSAGE_DOWNLOAD);
        mRequestMap.clear();
    }

    private void handleRequest(final T target){
        try{
            final String url = mRequestMap.get(target);
            if(url == null){
                return;
            }

            byte[] bitmapBytes = new FlickrFetchr().getUrlBytes(url);
            final Bitmap bitmap = BitmapFactory.decodeByteArray(bitmapBytes, 0, bitmapBytes.length);
            Log.i(TAG, "bitmap created");

            //mResponseHandler is associated with the main thread and so run() will be executed on
            //the main thread
            mResponseHandler.post(new Runnable() {
                @Override
                public void run() {
                    if(mRequestMap.get(target) != url || mHasQuit){
                        return;
                    }
                    mRequestMap.remove(target);
                    mThumbnailDownloadListener.onThumbnailDownloaded(target, bitmap);
                }
            });

        }catch(IOException ioe){
            Log.e(TAG, "Error downloading image", ioe);
        }
    }
}
