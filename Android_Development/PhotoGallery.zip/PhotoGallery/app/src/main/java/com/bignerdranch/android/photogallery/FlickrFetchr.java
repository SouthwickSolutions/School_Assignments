package com.bignerdranch.android.photogallery;

import android.net.Uri;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

//this class handles all of the networking
public class FlickrFetchr {

    private static final String TAG = "FlickrFetchr";
    private static final String API_KEY = "4ec61c67421b2b83337ee5f5be0a1704";

    //fetches raw data from a URL and returns it as an array of bytes
    public byte[] getUrlBytes(String urlSpec) throws IOException{
        URL url = new URL(urlSpec);

        //creates a connection object pointed at the URL and allows you to use HTTP specific request
        //methods, response codes, streaming methods, and more
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        try{
            //***** continuously reads the page until there is no more data
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            //the HttpURLConnection from above won't connect to your endpoint until you call getInputStream()
            InputStream in = connection.getInputStream();

            if(connection.getResponseCode() != HttpURLConnection.HTTP_OK){
                throw new IOException(connection.getResponseMessage() +
                            ": with " +
                            urlSpec);
            }
            //*****

            //*****writes the byte stream to out and returns the byte stream
            int bytesRead = 0;
            byte[] buffer = new byte[1024];
            while((bytesRead = in.read(buffer)) > 0){
                out.write(buffer, 0, bytesRead);
            }
            out.close();
            return out.toByteArray();
            //*****
        } finally {
            connection.disconnect();
        }
    }

    //converts the result from getUrlBytes to a String
    public String getUrlString(String urlSpec) throws IOException{
        return new String(getUrlBytes(urlSpec));
    }

    //builds an appropriate request URL and fetches its contents
    public List<GalleryItem> fetchItems(){

        List<GalleryItem> items = new ArrayList<>();

        try{
            //builds the complete URL for the flickr API request
            //https://api.flickr.com/services/rest/?method=flickr.photos.getRecent&api_key=4ec61c67421b2b83337ee5f5be0a1704&fformat=json&nojsoncallback=1
            String url = Uri.parse("https://api.flickr.com/services/rest")
                    .buildUpon()
                    .appendQueryParameter("method", "flickr.photos.getRecent")
                    .appendQueryParameter("api_key", API_KEY)
                    .appendQueryParameter("format", "json")
                    .appendQueryParameter("nojsoncallback", "1")
                    .appendQueryParameter("extras", "url_s")
                    .build().toString();
            String jsonString = getUrlString(url);
            Log.i(TAG, "Received JSON: " + jsonString);

            //parses json text into corresponding Java objects resulting in an object hierarchy that
            //maps to the original json text
            JSONObject jsonBody = new JSONObject(jsonString);
            parseItems(items, jsonBody);
        } catch(IOException ioe){
            Log.e(TAG, "Failed to fetch items", ioe);
        } catch(JSONException je){
            Log.e(TAG, "Failed to parse JSON", je);
        }

        return items;
    }

    //pulls out information for each photo, makes a GalleryItem for each photo and adds it to a List
    private void parseItems(List<GalleryItem> items, JSONObject jsonBody) throws IOException, JSONException{
        JSONObject photosJsonObject = jsonBody.getJSONObject("photos");
        JSONArray photosJsonArray = photosJsonObject.getJSONArray("photo");

        for(int i = 0; i < photosJsonArray.length(); i++){
            JSONObject photoJsonObject = photosJsonArray.getJSONObject(i);
            GalleryItem item = new GalleryItem();
            item.setmId(photoJsonObject.getString("id"));
            item.setmCaption(photoJsonObject.getString("title"));

            //flickr does not always return a url_s. This if statement checks that to ignore it
            if(!photoJsonObject.has("url_s")){
                continue;
            }

            item.setmUrl(photoJsonObject.getString("url_s"));

            items.add(item);
        }
    }
}

