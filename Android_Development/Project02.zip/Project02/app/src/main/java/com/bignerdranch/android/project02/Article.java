package com.bignerdranch.android.project02;

import java.util.UUID;

// ***5/7***
class Article {

    private UUID mId;
    private String mArticleTitle;
    private String mArticleUrl;

    Article(){
        mId = UUID.randomUUID();
    }

    UUID getUuid(){
        return mId;
    }

    String getArticleTitle(){
        return mArticleTitle;
    }

    String getArticleUrl(){return mArticleUrl;}

    void setArticleTitle(String title){
        this.mArticleTitle = title;
    }

    void setArticleUrl(String url){this.mArticleUrl = url; }
}