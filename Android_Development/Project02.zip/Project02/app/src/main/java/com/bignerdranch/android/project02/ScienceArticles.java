package com.bignerdranch.android.project02;

import android.content.Context;
import android.util.Log;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

// ***4/7***
public class ScienceArticles {

    public static ScienceArticles sScienceArticles;

    private List<Article> mArticles;
    private List<String> mArticleTitles;

    public static ScienceArticles get(Context context) throws IOException {
        if(sScienceArticles == null){
            sScienceArticles = new ScienceArticles(context);
        }
        return sScienceArticles;
    }

    private ScienceArticles(Context context) throws IOException {
        mArticles = new ArrayList<>();
        mArticleTitles = new ArrayList<>();

        //populate mArticleTitles and mArticleLinks by parsing the science site
        populateArticleTitlesAndLinks();

        for(int i = 0; i < mArticleTitles.size(); i++) {
            Article article = new Article();
            article.setArticleTitle(mArticleTitles.get(i));
            //article.setArticleIcon();

            mArticles.add(article);
        }
    }

    public List<Article> getArticles(){
        return mArticles;
    }

    public Article getArticle(UUID id){
        for(Article article : mArticles){
            if(article.getUuid().equals(id)){
                return article;
            }
        }
        return null;
    }

    private void populateArticleTitlesAndLinks(){
        /* This is the brains of the app. This method parses www.sciencenews.org and populates the
        *  article title array and the article link array.
        *
        *  The called JSoup methods have to handle an IOException. This is why you see try/catch
        *  across the application code.
        *
        *  To connect to the site, I have to open a new thread to avoid errors. See:
        *  https://stackoverflow.com/questions/8791061/jsoup-connect-working-with-java-not-with-android
        *
        *  Since the program has to access the internet, a permission needs to be set in the manifest.
        *  See:
        *  https://stackoverflow.com/questions/2169294/how-to-add-manifest-permission-to-android-application
        */

        Thread downloadThread = new Thread() {
            public void run() {
                Document doc;
                try {
                    doc = Jsoup.connect("http://www.sciencenews.org").get();
                    String title = doc.title();
                    Log.i("TITLE", title);
                    Elements links = doc.getElementsByTag("a");
                    for (Element link : links) {
                        String linkHref = link.attr("href");
                        String linkText = link.text();
                        if(linkText.length() > 50) {
                            mArticleTitles.add(linkText);
                            //Log.i("ATTR", "http://www.sciencenews.org" + linkHref);
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        downloadThread.start();
        //this sleep method needs to be put in to allow time for mArticleTitles to be updated by downloadThread
        try {
            downloadThread.sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //Log.i("ArticleTitle", mArticleTitles.get(mArticleTitles.size()-1));
    }
}