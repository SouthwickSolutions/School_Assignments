package com.bignerdranch.android.project02;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;

// ***3/7***
public class ArticleListFragment extends Fragment {

    private static int sArticleCounter = 0;

    private RecyclerView mArticleRecyclerView;
    private ArticleAdapter mAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_article_list, container, false);

        mArticleRecyclerView = view.findViewById(R.id.article_recycler_view);
        mArticleRecyclerView.setLayoutManager(new LinearLayoutManager((getActivity())));

        updateInterface();

        return view;
    }

    @Override
    public void onResume(){
        super.onResume();
        updateInterface();
    }

    private void updateInterface(){
        ScienceArticles scienceArticles = null;
        try {
            scienceArticles = ScienceArticles.get(getActivity());
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<Article> articles = scienceArticles.getArticles();

        if(mAdapter == null){
            mAdapter = new ArticleAdapter(articles);
            mArticleRecyclerView.setAdapter(mAdapter);
        }else{
            mAdapter.notifyDataSetChanged();
        }
    }

    private class ArticleHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        private Article mArticle;

        private TextView mTitleTextView;
        private ImageView mIconImageView;

        public ArticleHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_article, parent, false));
            itemView.setOnClickListener(this);

            mTitleTextView = itemView.findViewById(R.id.article_title);
            mIconImageView = itemView.findViewById(R.id.article_icon);
        }

        public void bind(Article article){
            mArticle = article;
            mTitleTextView.setText(mArticle.getArticleTitle());


            int counter = sArticleCounter % 10;
            switch(counter){
                case 0:
                    mIconImageView.setImageResource(R.drawable.article_icon01);
                    break;
                case 1:
                    mIconImageView.setImageResource(R.drawable.article_icon02);
                    break;
                case 2:
                    mIconImageView.setImageResource(R.drawable.article_icon03);
                    break;
                case 3:
                    mIconImageView.setImageResource(R.drawable.article_icon04);
                    break;
                case 4:
                    mIconImageView.setImageResource(R.drawable.article_icon05);
                    break;
                case 5:
                    mIconImageView.setImageResource(R.drawable.article_icon06);
                    break;
                case 6:
                    mIconImageView.setImageResource(R.drawable.article_icon07);
                    break;
                case 7:
                    mIconImageView.setImageResource(R.drawable.article_icon08);
                    break;
                case 8:
                    mIconImageView.setImageResource(R.drawable.article_icon09);
                    break;
                case 9:
                    mIconImageView.setImageResource(R.drawable.article_icon10);
                    break;
            }

            sArticleCounter++;
        }

        @Override
        public void onClick(View view){
            Intent intent = ArticlePagerActivity.newIntent(getActivity(), mArticle.getUuid());
            startActivity(intent);
        }
    }

    private class ArticleAdapter extends RecyclerView.Adapter<ArticleHolder>{

        private List<Article> mArticles;

        public ArticleAdapter(List<Article> articles){
            mArticles = articles;
        }

        @Override
        public ArticleHolder onCreateViewHolder(ViewGroup parent, int viewType){
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());

            return new ArticleHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ArticleHolder holder, int position){
            Article article = mArticles.get(position);
            holder.bind(article);
        }

        @Override
        public int getItemCount(){
            return mArticles.size();
        }
    }
}
