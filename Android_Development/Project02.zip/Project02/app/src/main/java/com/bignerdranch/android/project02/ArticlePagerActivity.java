package com.bignerdranch.android.project02;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

//***6/7***
public class ArticlePagerActivity extends AppCompatActivity{

    private static final String EXTRA_ARTICLE_ID = "com.bignerdranch.android.project2.article_id";

    private ViewPager mViewPager;
    private List<Article> mArticles;

    public static Intent newIntent(Context packageContext, UUID articleId){
        Intent intent = new Intent(packageContext, ArticlePagerActivity.class);
        intent.putExtra(EXTRA_ARTICLE_ID, articleId);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_pager);

        UUID articleId = (UUID) getIntent().getSerializableExtra(EXTRA_ARTICLE_ID);

        mViewPager = findViewById(R.id.article_view_pager);

        try {
            mArticles = ScienceArticles.get(this).getArticles();
        } catch (IOException e) {
            e.printStackTrace();
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        mViewPager.setAdapter(new FragmentStatePagerAdapter(fragmentManager) {

            @Override
            public Fragment getItem(int position) {
                Article article = mArticles.get(position);
                return ArticleFragment.newInstance(article.getUuid());
            }

            @Override
            public int getCount() {
                return mArticles.size();
            }
        });

        for(int i = 0; i < mArticles.size(); i++){
            if(mArticles.get(i).getUuid().equals(articleId)){
                mViewPager.setCurrentItem(i);
                break;
            }
        }
    }
}
