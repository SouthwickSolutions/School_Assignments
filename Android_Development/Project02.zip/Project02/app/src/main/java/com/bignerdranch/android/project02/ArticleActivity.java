package com.bignerdranch.android.project02;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;

import java.util.UUID;

// ***6/7***
public class ArticleActivity extends LoneFragmentActivity{

    private static final String EXTRA_ARTICLE_ID = "com.bignerdranch.android.project02.article_id";

    public static Intent newIntent(Context packageContext, UUID articleId){
        Intent intent = new Intent(packageContext, ArticleActivity.class);
        intent.putExtra(EXTRA_ARTICLE_ID, articleId);
        return intent;
    }

    @Override
    protected Fragment createFragment(){
        UUID articleId = (UUID) getIntent().getSerializableExtra(EXTRA_ARTICLE_ID);
        return ArticleFragment.newInstance(articleId);
    }
}
