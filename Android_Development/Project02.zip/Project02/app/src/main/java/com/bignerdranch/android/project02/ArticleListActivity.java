package com.bignerdranch.android.project02;

import android.support.v4.app.Fragment;

// ***1/7***
public class ArticleListActivity extends LoneFragmentActivity{

    @Override
    protected Fragment createFragment(){
        return new ArticleListFragment();
    }
}
