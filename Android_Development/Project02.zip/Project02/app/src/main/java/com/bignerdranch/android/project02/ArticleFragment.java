package com.bignerdranch.android.project02;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.util.UUID;

// ***7/7***
public class ArticleFragment extends Fragment{

    private static final String ARG_ARTICLE_ID = "article_id";

    private Article mArticle;
    private Button mBackButton;
    private Button mLaunchButton;
    private TextView mArticleTitleTextView;

    String mArticleTitle;
    String mArticleUrl;

    public static ArticleFragment newInstance(UUID articleId){
        Bundle args = new Bundle();
        args.putSerializable(ARG_ARTICLE_ID, articleId);
        ArticleFragment fragment = new ArticleFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public ArticleFragment(){
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UUID articleId = (UUID) getArguments().getSerializable(ARG_ARTICLE_ID);
        try {
            mArticle = ScienceArticles.get(getActivity()).getArticle(articleId);
            mArticleTitle = mArticle.getArticleTitle();
            mArticleUrl = mArticle.getArticleUrl();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View v = inflater.inflate(R.layout.fragment_article, container, false);

        mBackButton = v.findViewById(R.id.back_button);
        mLaunchButton = v.findViewById(R.id.launch_button);
        mArticleTitleTextView = v.findViewById(R.id.article_title);

        mBackButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        mLaunchButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Uri uri = Uri.parse(mArticleUrl);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        mArticleTitleTextView.setText(mArticleTitle);

        return v;
    }
}
