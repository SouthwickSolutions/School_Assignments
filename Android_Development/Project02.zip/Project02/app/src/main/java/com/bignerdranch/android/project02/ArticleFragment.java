package com.bignerdranch.android.project02;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ScrollView;

import java.io.IOException;
import java.util.UUID;

// ***7/7***
public class ArticleFragment extends Fragment{

    private static final String ARG_ARTICLE_ID = "article_id";

    private Article mArticle;
    private ScrollView mScrollView;
    private Button mBackButton;

    public static ArticleFragment newInstance(UUID articleId){
        Bundle args = new Bundle();
        args.putSerializable(ARG_ARTICLE_ID, articleId);
        ArticleFragment fragment = new ArticleFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public ArticleFragment(){
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UUID articleId = (UUID) getArguments().getSerializable(ARG_ARTICLE_ID);
        try {
            mArticle = ScienceArticles.get(getActivity()).getArticle(articleId);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View v = inflater.inflate(R.layout.fragment_article, container, false);

        mScrollView = v.findViewById(R.id.scroll_view);
        mBackButton = v.findViewById(R.id.back_button);

        return v;
    }
}
