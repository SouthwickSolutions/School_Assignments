package com.bignerdranch.android.criminalintent;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import java.util.List;
import java.util.UUID;

//***SIXTH POINT***
public class CrimePagerActivity extends AppCompatActivity{

    private static final String EXTRA_CRIME_ID = "com.bignerdranch.android.criminalintent.crime_id";


    private ViewPager mViewPager;
    private List<Crime> mCrimes;

    public static Intent newIntent(Context packageContext, UUID crimeId){
        Intent intent = new Intent(packageContext, CrimePagerActivity.class);
        intent.putExtra(EXTRA_CRIME_ID, crimeId);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crime_pager);

        UUID crimeId = (UUID) getIntent().getSerializableExtra(EXTRA_CRIME_ID);

        mViewPager = findViewById(R.id.crime_view_pager); //finds the ViewPager in the activity's view

        mCrimes = CrimeLab.get(this).getCrimes(); //gets the list of crimes
        //creating the FragmentStatePagerAdapter requires the FragmentManager. FragmentStatePagerAdapter
        //is your agent managing the conversation with ViewPager which is why you need FragmentManager.
        //what exactly is FragmentStatePagerAdapter doing? It is adding the fragments you return to
        //your activity and helping ViewPager identify the fragments' views so that they can be placed
        //correctly.
        FragmentManager fragmentManager = getSupportFragmentManager(); //gets the Activity's instance of FragmentManager
        mViewPager.setAdapter(new FragmentStatePagerAdapter(fragmentManager){ //sets the adapter to be an unnamed instance of FragmentStatePagerAdapter

            @Override
            //this is where the magic happens. Here, we fetch the Crime instance for the given
            //position in the data set. Then, it uses that Crime's ID to create and return a properly
            //configured CrimeFragment
            public Fragment getItem(int position) {
                Crime crime = mCrimes.get(position);
                return CrimeFragment.newInstance(crime.getId());
            }

            @Override
            public int getCount() {
                return mCrimes.size();
            }
        });

        //starts the ViewPager at the crime you selected
        for(int i = 0; i < mCrimes.size(); i++){
            if(mCrimes.get(i).getId().equals(crimeId)){
                mViewPager.setCurrentItem(i);
                break;
            }
        }
    }
}
