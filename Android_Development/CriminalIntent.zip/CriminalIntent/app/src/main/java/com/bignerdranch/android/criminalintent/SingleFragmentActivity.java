package com.bignerdranch.android.criminalintent;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

//***SECOND POINT***
//here, you look for the fragment in the FragmentManager in that container, creating and adding it
//if it does not exist.
public abstract class SingleFragmentActivity extends AppCompatActivity {
    protected abstract Fragment createFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment); //set the activity's view to be inflated from
        // activity_fragment

        //FragmentManager is responsible for managing your fragments and adding their views to the
        //activity's view hierarchy.
        //FragmentManager handles two things: a list of fragments and a backstack of fragment
        //transactions.
        //To add a fragment to an activity in code, you make explicit calls to the Activity's
        //FragmentManager.
        //getSupportFragmentMAnager() is called because you are using a support library. Otherwise,
        //you would use getFragmentManager().
        FragmentManager fm = getSupportFragmentManager();
        Fragment fragment = fm.findFragmentById(R.id.fragment_container); //look for the fragment
        // inside the fragment manager

        //if you can't find the fragment, then create it
        if(fragment == null){
            fragment = createFragment();
            //a fragment transaction is used to add, remove, attach, detach fragments.
            //beginTransaction() is a fragment transaction example and this one is adding a fragment
            //if it cannot be found
            fm.beginTransaction().add(R.id.fragment_container, fragment).commit();
        }
    }
}
