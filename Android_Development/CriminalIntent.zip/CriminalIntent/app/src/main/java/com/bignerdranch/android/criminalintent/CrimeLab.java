package com.bignerdranch.android.criminalintent;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CrimeLab {
    public static CrimeLab sCrimeLab;

    //diamnond notation, < > , tells the compiler to infer the type of items the List will contain
    // based on the generic argument passed in the variable declaration
    private List<Crime> mCrimes; //list of crimes

    public static CrimeLab get(Context context){
        if(sCrimeLab == null){
            sCrimeLab = new CrimeLab(context);
        }
        return sCrimeLab;
    }

    private CrimeLab(Context context){
        mCrimes = new ArrayList<>(); //uses a regular Java array to store the list elements
        for(int i = 0; i < 100; i++){ //adds 100 crimes to the array
            Crime crime = new Crime();
            crime.setTitle("Crime #" + i);
            crime.setSolved(i % 2 == 0); //every other one
            mCrimes.add(crime);
        }
    }

    public List<Crime> getCrimes(){ //returns all crimes
        return mCrimes;
    }

    public Crime getCrime(UUID id){ //returns a crime with the given ID
        for(Crime crime : mCrimes){
            if(crime.getId().equals(id)){
                return crime;
            }
        }
        return null;
    }
}
