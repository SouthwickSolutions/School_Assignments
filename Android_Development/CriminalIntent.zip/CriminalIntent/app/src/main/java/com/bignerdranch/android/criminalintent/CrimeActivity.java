package com.bignerdranch.android.criminalintent;

import android.support.v4.app.Fragment;

public class CrimeActivity extends SingleFragmentActivity {

    //commented out and kept to demonstrate concepts. This code was put in at the beginning of the
    // chapter but is now in SingleFragmentActivity
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_fragment);
//
//        FragmentManager fm = getSupportFragmentManager(); //you call this method because you are
//        // using the support library and the AppCompatActivity class
//        Fragment fragment = fm.findFragmentById(R.id.fragment_container); //here,  you are asking
//        // the fragment manager for this fragment. If it is already in the list, the fragment
//        // manager will return it
//
//        if(fragment == null){ //create a new fragment transaction if there isn't one already,
//            // add the view and then commit it
//            fragment = new CrimeFragment();
//            fm.beginTransaction().add(R.id.fragment_container, fragment).commit();
//        }
//    }

    @Override
    protected Fragment createFragment(){
        return new CrimeFragment();
    }
}
