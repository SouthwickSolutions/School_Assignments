package com.bignerdranch.android.criminalintent;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CrimeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crime);

        FragmentManager fm = getSupportFragmentManager(); //you call this method because you are
        // using the support library and the AppCompatActivity class
        Fragment fragment = fm.findFragmentById(R.id.fragment_container); //here,  you are asking
        // the fragment manager for this fragment. If it is already in the list, the fragment
        // manager will return it

        if(fragment == null){ //create a new fragment transaction if there isn't one already,
            // add the view and then commit it
            fragment = new CrimeFragment();
            fm.beginTransaction().add(R.id.fragment_container, fragment).commit();
        }
    }
}
