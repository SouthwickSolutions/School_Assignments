package com.bignerdranch.android.criminalintent;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.List;

//***THIRD POINT***
//The private CrimeHolder class is a ViewHolder that holds on to a view. A RecyclerView never
//creates Views by themselves. It always creates ViewHolders, which bring their itemViews along for
//the ride.
//RecyclerView does not create ViewHolders itself. Instead, it asks an adapter. An adapter is a
//controller object that sits between the RecyclerView and the data set that the RecyclerView should
//display. The adapter is responsible for: creating the necessary ViewHolders binding ViewHolders to
//data from the model layer. When the RecyclerView needs a view object to display, it will have a
//conversation with its adapter.
public class CrimeListFragment extends Fragment {

    private static final String SAVED_SUBTITLE_VISIBLE = "subtitle";

    private RecyclerView mCrimeRecyclerView;
    private CrimeAdapter mAdapter;
    private boolean mSubtitleVisible;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        //this is where you inflate the layout for the fragment view and return it to the hosting
        //activity. The second parameter (container) is the view's parent. The third parameter
        //determines if you are going to add this view to the view's parent. We put false because we
        //are going to add the view in the activity's code
        View view = inflater.inflate(R.layout.fragment_crime_list, container, false);

        //this RecyclerView is in fragment_crime_list.xml
        mCrimeRecyclerView = (RecyclerView) view.findViewById(R.id.crime_recycler_view);
        mCrimeRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity())); //RecyclerView
        //needs a LayoutManager to work. If you do not give the RecyclerView a layout manager, it
        //will crash.
        //RecyclerView does not position items on the screen itself. It delegates that job to the
        //LayoutManager. The LayoutManager positions every item and also defines how scrolling
        //works. So if RecyclerView tries to do those things when the LayoutManager is not there,
        //the RecyclerView will immediately fall over and die.
        //There are a few built-in LayoutManagers to choose from, and you can find more as
        //third-party libraries. You are using the LinearLayoutManager, which will position the
        //items in the list vertically.

        if(savedInstanceState != null){
            mSubtitleVisible = savedInstanceState.getBoolean(SAVED_SUBTITLE_VISIBLE);
        }

        updateUI(); //sets up CrimeListFragment's UI

        return view;
    }

    @Override
    public void onResume(){
        super.onResume();
        updateUI();
    }

    @Override
    public void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        outState.putBoolean(SAVED_SUBTITLE_VISIBLE, mSubtitleVisible);
    }

    //this method inflates the toolbar menu. The FragmentManager is responsible for calling this inflater,
    //but you must explicitly tell it with setHasOptionsMenu method. This is done in the above onCreate
    //method
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater){
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_crime_list, menu);

        MenuItem subtitleItem = menu.findItem(R.id.show_subtitle);
        if(mSubtitleVisible){
            subtitleItem.setTitle(R.string.hide_subtitle);
        }else{
            subtitleItem.setTitle(R.string.show_subtitle);
        }
    }

    //to respond to the user pressing the New Crime action item, you need a way to add a new Crime to
    //your list of crimes.
    //When the user presses an action item, your fragment receives a callback to this method.
    //MenuItem describes the user’s selection and can often have multiple items to select from.
    //you can determine which action item has been selected by checking the ID (that you set in the
    //menu XML file) of the MenuItem
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.new_crime:
                Crime crime = new Crime();
                CrimeLab.get(getActivity()).addCrime(crime);
                Intent intent = CrimePagerActivity.newIntent(getActivity(), crime.getId());
                startActivity(intent);
                return true;
            case R.id.show_subtitle:
                mSubtitleVisible = !mSubtitleVisible;
                getActivity().invalidateOptionsMenu();
                updateSubtitle();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //sets the subtitle of the toolbar to display the number of crimes
    private void updateSubtitle(){
        CrimeLab crimeLab = CrimeLab.get(getActivity());
        int crimeCount = crimeLab.getCrimes().size();
        String subtitle = getString(R.string.subtitle_format, crimeCount);

        if(!mSubtitleVisible){
            subtitle = null;
        }

        AppCompatActivity activity = (AppCompatActivity) getActivity();
        activity.getSupportActionBar().setSubtitle(subtitle);
    }

    private void updateUI(){
        CrimeLab crimeLab = CrimeLab.get(getActivity()); //initiates the CrimeLab singleton. The
        //getActivity() method returns the activity that this fragment is associated with
        List<Crime> crimes = crimeLab.getCrimes(); //gets all of the crimes

        if(mAdapter == null) {
            mAdapter = new CrimeAdapter(crimes);
            mCrimeRecyclerView.setAdapter(mAdapter);
        }else{
            mAdapter.setCrimes(crimes);
            mAdapter.notifyDataSetChanged(); //Notifies the attached observers that the underlying
            //data has been changed and any View reflecting the data set should refresh itself.
        }

        updateSubtitle();
    }

    private class CrimeHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        private Crime mCrime;

        private TextView mTitleTextView;
        private TextView mDateTextView;
        private ImageView mSolvedImageView;

        public CrimeHolder(LayoutInflater inflater, ViewGroup parent){
            //Here, you inflate list_item_crime.xml. Immediately you pass it into super(…),
            //ViewHolder’s constructor. The base ViewHolder class will then hold on to the
            //fragment_crime_list.xml view hierarchy.
            super(inflater.inflate(R.layout.list_item_crime, parent, false));
            //CrimeHolder itself is implementing the OnClickListener interface. On the itemView,
            //which is the View for the entire row, the CrimeHolder is set as the receiver of click
            //events.
            itemView.setOnClickListener(this);

            mTitleTextView = (TextView) itemView.findViewById(R.id.crime_title);
            mDateTextView = (TextView) itemView.findViewById(R.id.crime_date);
            mSolvedImageView = (ImageView) itemView.findViewById(R.id.crime_solved);
        }

        //updates the title TextView and date TextView to reflect the state of the crime
        public void bind(Crime crime){
            mCrime = crime;
            mTitleTextView.setText(mCrime.getTitle());
            mDateTextView.setText(mCrime.getDate().toString());
            mSolvedImageView.setVisibility(crime.isSolved() ? View.VISIBLE : View.GONE);//this line
            //is what determines if the handcuffs show up or not
        }

        //starts the CrimeActivity activity
        @Override
        public void onClick(View view){
            Intent intent = CrimePagerActivity.newIntent(getActivity(), mCrime.getId());
            startActivity(intent);
        }
    }

    private class CrimeAdapter extends RecyclerView.Adapter<CrimeHolder>{

        private List<Crime> mCrimes;

        public CrimeAdapter(List<Crime> crimes){
            mCrimes = crimes;
        }

        @Override
        //called by the RecyclerView when it needs a new ViewHolder to display an item with
        public CrimeHolder onCreateViewHolder(ViewGroup parent, int viewType){
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());

            return new CrimeHolder(layoutInflater, parent);
        }

        //The RecyclerView will pass a ViewHolder into this method along with the position. The
        //adapter will look up the model data for that position and bind it to the ViewHolder’s
        //View. To bind it, the adapter fills in the View to reflect the data in the model object.
        @Override
        public void onBindViewHolder(CrimeHolder holder, int position){
            Crime crime = mCrimes.get(position);
            holder.bind(crime);
        }

        @Override
        public int getItemCount(){
            return mCrimes.size();
        }

        public void setCrimes(List<Crime> crimes){
            mCrimes = crimes;
        }
    }
}
