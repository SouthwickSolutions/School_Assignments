package com.bignerdranch.android.criminalintent;

import android.support.v4.app.Fragment;

//***FIRST POINT***
//used with CrimeListFragment to display crimes. Essentially, the main outer part of the activity
public class CrimeListActivity extends SingleFragmentActivity{

    @Override
    protected Fragment createFragment(){
        return new CrimeListFragment();
    }
}
