package com.bignerdranch.android.project01;



public class Facts {

    private int mTextResId;

    public Facts(int textResId){
        mTextResId = textResId;
    }

    public int getTextResId(){return mTextResId;}
}