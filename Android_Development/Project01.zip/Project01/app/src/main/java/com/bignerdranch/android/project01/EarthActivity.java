package com.bignerdranch.android.project01;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class EarthActivity extends AppCompatActivity {

    public static final String USER_NAME_EARTH = "com.bignerdranch.android.project01.user_name_earth";

    private TextView mRandomFactTextView;

    public static Intent newIntent(Context packageContext, String name){
        Intent intent = new Intent(packageContext, EarthActivity.class);
        intent.putExtra(USER_NAME_EARTH, name);
        return intent;
    }

    private Facts[] mEarthFactsBank = new Facts[]{
            new Facts(R.string.earth_fact_one),
            new Facts(R.string.earth_fact_two),
            new Facts(R.string.earth_fact_three),
            new Facts(R.string.earth_fact_four),
            new Facts(R.string.earth_fact_five)
    };

    private int mCurrentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earth);

        final String mName = getIntent().getStringExtra(USER_NAME_EARTH);

        Button randomFactButton = findViewById(R.id.earth_random_fact_button);
        Button backButton = findViewById(R.id.earth_back_button);
        mRandomFactTextView = findViewById(R.id.current_earth_fact);

        randomFactButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mCurrentIndex = (mCurrentIndex + 1) % mEarthFactsBank.length;
                updateFact();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = MainActivity.newIntent(EarthActivity.this, mName);
                startActivity(intent);
            }
        });
    }

    private void updateFact(){
        int fact = mEarthFactsBank[mCurrentIndex].getTextResId();
        mRandomFactTextView.setText(fact);
    }
}
