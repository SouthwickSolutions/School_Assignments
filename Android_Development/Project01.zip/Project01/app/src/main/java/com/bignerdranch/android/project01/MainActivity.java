package com.bignerdranch.android.project01;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String USER_NAME_MAIN = "com.bignerdranch.android.project01.user_name_main";

    private static final int REQUEST_CODE_MERCURY = 0;
    private static final int REQUEST_CODE_VENUS = 1;
    private static final int REQUEST_CODE_EARTH = 2;
    private static final int REQUEST_CODE_MARS = 3;

    static boolean mOnCreateFirstTime = true;

    static String mName;

    public static Intent newIntent(Context packageContext, String name){
        Intent intent = new Intent(packageContext, MainActivity.class);
        intent.putExtra(USER_NAME_MAIN, name);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(mOnCreateFirstTime == true) {
            mName = getIntent().getStringExtra(USER_NAME_MAIN);
            String welcome = "Welcome " + mName + ", select a planet.";
            Toast.makeText(this, welcome, Toast.LENGTH_LONG).show();
            mOnCreateFirstTime = false;
        }

        Button mercuryButton = (Button) findViewById(R.id.mercury_button);
        Button venusButton = (Button) findViewById(R.id.venus_button);
        Button earthButton = (Button) findViewById(R.id.earth_button);
        Button marsButton = (Button) findViewById(R.id.mars_button);

        mercuryButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = MercuryActivity.newIntent(MainActivity.this, mName);
                startActivityForResult(intent, REQUEST_CODE_MERCURY);
            }
        });

        venusButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = VenusActivity.newIntent(MainActivity.this, mName);
                startActivityForResult(intent, REQUEST_CODE_VENUS);
            }
        });

        earthButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = EarthActivity.newIntent(MainActivity.this, mName);
                startActivityForResult(intent, REQUEST_CODE_EARTH);
            }
        });

        marsButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = MarsActivity.newIntent(MainActivity.this, mName);
                startActivityForResult(intent, REQUEST_CODE_MARS);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(requestCode == REQUEST_CODE_MERCURY){
            String welcomeBackFromMercury = "Welcome back from Mercury " + mName +", select another planet.";
            Toast.makeText(this, welcomeBackFromMercury, Toast.LENGTH_LONG).show();
        }
        if(requestCode == REQUEST_CODE_VENUS){
            String welcomeBackFromVenus = "Welcome back from Venus " + mName +", select another planet.";
            Toast.makeText(this, welcomeBackFromVenus, Toast.LENGTH_LONG).show();
        }
        if(requestCode == REQUEST_CODE_EARTH){
            String welcomeBackFromEarth = "Welcome back from Earth " + mName +", select another planet.";
            Toast.makeText(this, welcomeBackFromEarth, Toast.LENGTH_LONG).show();
        }
        if(requestCode == REQUEST_CODE_MARS){
            String welcomeBackFromMars = "Welcome back from Mars " + mName +", select another planet.";
            Toast.makeText(this, welcomeBackFromMars, Toast.LENGTH_LONG).show();
        }
    }
}