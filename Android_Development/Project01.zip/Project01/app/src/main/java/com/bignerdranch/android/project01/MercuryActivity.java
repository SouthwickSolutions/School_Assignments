package com.bignerdranch.android.project01;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MercuryActivity extends AppCompatActivity {

    public static final String USER_NAME_MERCURY = "com.bignerdranch.android.project01.user_name_mercury";

    private TextView mRandomFactTextView;

    public static Intent newIntent(Context packageContext, String name){
        Intent intent = new Intent(packageContext, MercuryActivity.class);
        intent.putExtra(USER_NAME_MERCURY, name);
        return intent;
    }

    private Facts[] mMercuryFactsBank = new Facts[]{
        new Facts(R.string.mercury_fact_one),
        new Facts(R.string.mercury_fact_two),
        new Facts(R.string.mercury_fact_three),
        new Facts(R.string.mercury_fact_four),
        new Facts(R.string.mercury_fact_five)
    };

    private int mCurrentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mercury);

        final String mName = getIntent().getStringExtra(USER_NAME_MERCURY);

        Button randomFactButton = findViewById(R.id.mercury_random_fact_button);
        Button backButton = findViewById(R.id.mercury_back_button);
        mRandomFactTextView = findViewById(R.id.current_mercury_fact);

        randomFactButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mCurrentIndex = (mCurrentIndex + 1) % mMercuryFactsBank.length;
                updateFact();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = MainActivity.newIntent(MercuryActivity.this, mName);
                startActivity(intent);
            }
        });
    }

    private void updateFact(){
        int fact = mMercuryFactsBank[mCurrentIndex].getTextResId();
        mRandomFactTextView.setText(fact);
    }
}