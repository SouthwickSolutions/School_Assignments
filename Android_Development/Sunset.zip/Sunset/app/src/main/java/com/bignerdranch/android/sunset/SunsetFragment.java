package com.bignerdranch.android.sunset;

import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;

public class SunsetFragment extends Fragment {

    private View mSceneView;
    private View mSunView;
    private View mSkyView;

    private int mBlueSkyColor;
    private int mSunsetSkyColor;
    private int mNightSkyColor;


    public static SunsetFragment newInstance(){
        return new SunsetFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_sunset, container, false);

        mSceneView = view;
        mSunView = view.findViewById(R.id.sun);
        mSkyView = view.findViewById(R.id.sky);

        Resources resources = getResources();
        mBlueSkyColor = resources.getColor(R.color.blue_sky);
        mSunsetSkyColor = resources.getColor(R.color.sunset_sky);
        mNightSkyColor = resources.getColor(R.color.night_sky);

        //here we are setting it to where you can press anywhere on the screen and the sun will set
        mSceneView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startAnimation();
            }
        });

        return view;
    }

    private void startAnimation(){
        float sunYStart = mSunView.getTop(); //one of four methods on View that returns the local
        //layout rect for that view. A view's local layout rect is the position and size of that
        //view in relation to its parent
        float sunYEnd = mSkyView.getHeight(); //returns the same thing as getBottom()-getTop(). This
        //will be how far the view needs to move

        ObjectAnimator heightAnimator = ObjectAnimator.ofFloat(mSunView,
                                                  "y",
                                                               sunYStart,
                                                               sunYEnd).setDuration(3000);//this is
        //the setup for animating the sun.

        heightAnimator.setInterpolator(new AccelerateInterpolator());

        ObjectAnimator sunsetSkyAnimator = ObjectAnimator.ofInt(mSkyView,
                                                   "backgroundColor",
                                                                mBlueSkyColor,
                                                                mSunsetSkyColor).setDuration(3000);//this
        //is the setup for animating the sky color

        sunsetSkyAnimator.setEvaluator(new ArgbEvaluator());//let you determine the values between
        //start and end for a color transition

        ObjectAnimator nightSkyAnimator = ObjectAnimator.ofInt(mSkyView,
                                                  "backgroundColor",
                                                               mSunsetSkyColor,
                                                               mNightSkyColor).setDuration(1500);//this
        // is the animation setup for the night sky
        nightSkyAnimator.setEvaluator(new ArgbEvaluator());

        AnimatorSet animatorSet = new AnimatorSet(); //an AnimatorSet is nothing more than a set of
        //animations that can be played together. "Play" lets you build a set of instructions. This
        //set of instructions read “Play heightAnimator with sunsetSkyAnimator; also, play
        //heightAnimator before nightSkyAnimator.”
        animatorSet
                .play(heightAnimator)
                .with(sunsetSkyAnimator)
                .before(nightSkyAnimator);
        animatorSet.start();

    }
}
