package com.bignerdranch.android.stormchaser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;


import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class DataGatherer_03 {

    JSONObject data = null;
    Context context;
    Activity activity;

    String weatherIconString;
    URL iconUrl;
    Bitmap image;
    String mainTemp;

    DataGatherer_03(Context context, Activity activity){
        getJSON();
        this.context = context;
        this.activity = activity;
    }

    @SuppressLint("StaticFieldLeak")
    public void getJSON() {
        new AsyncTask<Void, Void, Void>(){
            @Override
            protected void onPreExecute(){
                super.onPreExecute();
            }

            @Override
            protected Void doInBackground(Void... params){
                try{
                    URL url = new URL("http://api.openweathermap.org/data/2.5/weather?zip=84790,us&units=imperial&APPID=9a8ec7730006d6ce453f9c3249c9ed1c");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuffer json = new StringBuffer(1024);
                    String tmp = "";

                    while((tmp = reader.readLine()) != null)
                        json.append(tmp).append("\n");
                    reader.close();

                    //initializes the pulled data here
                    data = new JSONObject(json.toString());

                    //the weather icon stuff in here in AsyncTask because it requires a network call on its own
                    weatherIconString = data.getJSONArray("weather")
                                            .getJSONObject(0)
                                            .getString("icon");
                    iconUrl = new URL("http://openweathermap.org/img/w/" + weatherIconString + ".png");
                    image = BitmapFactory.decodeStream(iconUrl.openConnection().getInputStream());

                    if(data.getInt("cod") != 200){
                        System.out.println("Cancelled");
                        return null;
                    }
                } catch (Exception e){
                    System.out.println("Exception "+ e.getMessage());
                    return null;
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void Void) {
                if(data!=null){
                    Log.d("JSON: ",data.toString());
                }
            }
        }.execute();
    }

    public void weatherDescription() throws JSONException {
        TextView weatherDescriptionText = activity.findViewById(R.id.weatherDescription);

        String weatherDescription = data.getJSONArray("weather")
                                        .getJSONObject(0)
                                        .getString("description");
        if(weatherDescription.equals("clear sky")) {
            weatherDescription = "clear skies";
        }
        weatherDescriptionText.setText(weatherDescription);
        weatherDescriptionText.setTextColor(Color.WHITE);
    }

    public void getWeatherIcon(){
        ImageView weatherIcon = activity.findViewById(R.id.WeatherIcon);
        Drawable drawable = new BitmapDrawable(context.getResources(), image);
        weatherIcon.setImageDrawable(drawable);
    }

    public void getMainTemp() throws JSONException {
        TextView mainTempText = activity.findViewById(R.id.temperature);
        mainTemp = Double.toString(data.getJSONObject("main").getDouble("temp"));
        mainTempText.setText("Currently: " + mainTemp + "°F");
        mainTempText.setTextColor(Color.WHITE);
    }

    public void getMainHumidity() throws JSONException {
        TextView mainHumidityText = activity.findViewById(R.id.humidity);
        String mainHumidity = Integer.toString(data.getJSONObject("main").getInt("humidity"));
        mainHumidityText.setText("Humidity: " + mainHumidity + "%");
        mainHumidityText.setTextColor(Color.WHITE);
    }

    public void getCloudsAll() throws JSONException {
        TextView cloudsAllText = activity.findViewById(R.id.visibility);
        String cloudsAll = Integer.toString((data.getJSONObject("clouds").getInt("all")) * 100);
        cloudsAllText.setText("Visibility: " + cloudsAll + "%");
        cloudsAllText.setTextColor(Color.WHITE);
    }

    public void getRain3h() throws JSONException {
        TextView rain3hText = activity.findViewById(R.id.rain);
        //check if data has rain
        if(data.has("rain")){
            String rainAmountPerHour= Double.toString((data.getJSONObject("rain").getDouble("3h")) / 3);
            rain3hText.setText("Rain per hour: " + rainAmountPerHour + " inches");
            rain3hText.setTextColor(Color.WHITE);
        }
        else{
            rain3hText.setText("Rain per hour: 0 inches");
            rain3hText.setTextColor(Color.WHITE);
        }
    }

    public void prepareInformation() throws JSONException {
        getWeatherIcon();
        getMainTemp();
        weatherDescription();
        getRain3h();
        getMainHumidity();
        getCloudsAll();
    }

    public String getTemperature(){
        String str = "Currently: " + mainTemp + "°F";
        return str;
    }
}
