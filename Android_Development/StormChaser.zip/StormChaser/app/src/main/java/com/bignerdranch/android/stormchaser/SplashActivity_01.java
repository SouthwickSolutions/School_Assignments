package com.bignerdranch.android.stormchaser;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SplashActivity_01 extends AppCompatActivity {

    private View mPartlyCloudyView;
    private View mSunnyView;
    private View mRainingView;
    private View mOvercastView;
    private View mLogoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        mPartlyCloudyView = findViewById(R.id.partly_cloudy);
        mSunnyView = findViewById(R.id.sunny);
        mRainingView = findViewById(R.id.raining);
        mOvercastView = findViewById(R.id.overcast);
        mLogoView = findViewById(R.id.logo);

        startAnimation();

        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {

            @Override
            public void run() {
                Intent intent = WeatherActivity_02.newIntent(SplashActivity_01.this);
                startActivity(intent);
            }

        }, 5500);
    }

    private void startAnimation(){
        float partlyCloudyXStart = mPartlyCloudyView.getLeft() - 300;
        float partlyCloudyXEnd = mPartlyCloudyView.getLeft() + 1100;

        float sunnyXStart = mSunnyView.getLeft() + 1000;
        float sunnyXEnd = mSunnyView.getLeft() - 400;

        float rainingXStart = mRainingView.getLeft() - 300;
        float rainingXEnd = mRainingView.getLeft() + 1100;

        float overcastXStart = mOvercastView.getLeft() + 1000;
        float overcastXEnd = mOvercastView.getLeft() - 400;

        float logoYStart = mLogoView.getTop() + 1500;
        float logoYEnd = mLogoView.getTop() + 500;

        ObjectAnimator partlyCloudyAnimator = ObjectAnimator.ofFloat(mPartlyCloudyView,
                                               "x",
                                                            partlyCloudyXStart,
                                                            partlyCloudyXEnd).setDuration(3000);

        ObjectAnimator sunnyAnimator = ObjectAnimator.ofFloat(mSunnyView,
                                                 "x",
                                                              sunnyXStart,
                                                              sunnyXEnd).setDuration(3000);

        ObjectAnimator rainingAnimator = ObjectAnimator.ofFloat(mRainingView,
                                                   "x",
                                                                rainingXStart,
                                                                rainingXEnd).setDuration(3000);

        ObjectAnimator overcastAnimator = ObjectAnimator.ofFloat(mOvercastView,
                                                    "x",
                                                                 overcastXStart,
                                                                 overcastXEnd).setDuration(3000);

        ObjectAnimator logoAnimator = ObjectAnimator.ofFloat(mLogoView,
                                                "y",
                                                             logoYStart,
                                                             logoYEnd).setDuration(2000);

        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet
                .play(partlyCloudyAnimator)
                .with(sunnyAnimator)
                .with(rainingAnimator)
                .with(overcastAnimator)
                .before(logoAnimator);

        animatorSet.start();
    }
}
