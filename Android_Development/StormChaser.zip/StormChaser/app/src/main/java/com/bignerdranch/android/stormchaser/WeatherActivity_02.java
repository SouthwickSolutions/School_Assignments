package com.bignerdranch.android.stormchaser;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import org.json.JSONException;

public class WeatherActivity_02 extends AppCompatActivity {

    DataGatherer_03 jsonController = new DataGatherer_03(WeatherActivity_02.this, this);
    String temperature;

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        //setup for the tap action of the notification
        Intent intent = new Intent(this, WeatherActivity_02.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        timeDelay(2000);
        try {
            //sets the top fragment information
            jsonController.prepareInformation();
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        //builds the notification
        NotificationCompat.Builder notificationBuild = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.smallicon)
                .setContentTitle("Current Temperature")
                .setContentText(jsonController.getTemperature())
                .setDefaults(NotificationCompat.DEFAULT_LIGHTS | NotificationCompat.DEFAULT_SOUND)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT);

        //calls the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(1, notificationBuild.build());

    }

    public static Intent newIntent(Context packageContext){
        Intent intent = new Intent(packageContext, WeatherActivity_02.class);
        return intent;
    }

    public void timeDelay(long t) {
        try {
            Thread.sleep(t);
        } catch (InterruptedException e) {}
    }
}
