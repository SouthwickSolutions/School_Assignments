package com.bignerdranch.android.stormchaser;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import org.json.JSONException;

public class WeatherActivity_02 extends AppCompatActivity {

    DataGatherer_03 jsonController = new DataGatherer_03(WeatherActivity_02.this, this);

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        timeDelay(2000);
        try {
            jsonController.prepareInformation();
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static Intent newIntent(Context packageContext){
        Intent intent = new Intent(packageContext, WeatherActivity_02.class);
        return intent;
    }

    public void timeDelay(long t) {
        try {
            Thread.sleep(t);
        } catch (InterruptedException e) {}
    }
}
