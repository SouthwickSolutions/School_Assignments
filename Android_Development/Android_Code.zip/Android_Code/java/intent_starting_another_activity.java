//activity 1 (QuizActivity)
Intent intent = CheatActivity.newIntent(QuizActivity.this, answerIsTrue);
startActivityForResult(intent, REQUEST_CODE_CHEAT);
//you can also call startActivity() if you do not need to head back from Activity 2



//activity 2 (CheatActivity)
public static Intent newIntent(Context packageContext, boolean answerIsTrue){
    Intent intent = new Intent(packageContext, CheatActivity.class);
    intent.putExtra(EXTRA_ANSWER_IS_TRUE, answerIsTrue);
    return intent;
}
