//bundles are generally used to pass data between activities. It is a mapping of
//string values to different data types

//you can pass the data with an intent:
Intent intent = new Intent(getApplicationContext(), SecondActivity.class);
intent.putExtra("key", value);

//you can receive the extras in a bundle
Bundle bundle = intent.getExtras();
String data = bundle.getString("key");
