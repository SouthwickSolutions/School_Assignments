//This code is called automatically. Put this code where you want it to be
//called. The first parameter is Context. The second parameter is an Int or
//CharSequence of the message. Int is the id of the text found in
//R.string.judgement_toast The third parameter is the length of the toast.
Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show();

//second parameter can also be a String
