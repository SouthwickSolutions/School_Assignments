package com.bignerdranch.android.picasso;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

//tutorial from https://www.youtube.com/watch?v=vrtsiY__Y3Y

//don't forget your Gradle implementation
//implementation 'com.squareup.picasso:picasso:2.71828'

//don't forget to add your internet permission in the manifest

public class MainActivity extends AppCompatActivity {

    ImageView ivImageFromUrl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivImageFromUrl = (ImageView) findViewById(R.id.iv_image_from_url);

        //code retrieved from http://square.github.io/picasso/
        Picasso.get().load("http://i.imgur.com/DvpvklR.png").into(ivImageFromUrl);
    }
}
