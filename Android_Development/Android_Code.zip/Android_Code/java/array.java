//array demonstration from GeoQuiz

//user created Question class where mQuestionBank is the var name and it holds an array of Question objects
private Question[] mQuestionBank = new Question[] {
    new Question(R.string.question_australia, true),
    new Question(R.string.question_oceans, true),
    new Question(R.string.question_mideast, false),
    new Question(R.string.question_africa, false),
    new Question(R.string.question_americas, true),
    new Question(R.string.question_asia, true),
};



//demonstration constructor found in the Question.java class
public class Question{
    private int mTextResId;
    private boolean mAnswerTrue;

    public Question(int textResId, boolean answerTrue){
        mTextResId = textResId;
        mAnswerTrue = answerTrue;
    }
}

//class should also have the following method which returns an int id set by
//textResId above. This is the location of the array index
public int getTextResId(){
    return mTextResId;
}
