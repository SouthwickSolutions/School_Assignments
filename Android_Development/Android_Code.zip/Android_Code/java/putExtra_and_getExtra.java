//putExtra is a key value pair of whaterver value you want.
//You would call


//class members
private static final String EXTRA_ANSWER_IS_TRUE = "com.bignerdranch.android.geoquiz.answer_is_true";
private static final String EXTRA_ANSWER_SHOWN = "com.bignerdranch.android.geoquiz.answer_shown";

//method in CheatActivity that demonstrates putting an extra
public static Intent newIntent(Context packageContext, boolean answerIsTrue){
    Intent intent = new Intent(packageContext, CheatActivity.class);
    intent.putExtra(EXTRA_ANSWER_IS_TRUE, answerIsTrue);
    return intent;
}

//method in CheatActivity that demonstrates getting a boolean extra
public static boolean wasAnswerShown(Intent result){
        return result.getBooleanExtra(EXTRA_ANSWER_SHOWN, false);
    }



//you can also get an extra this way. This code was towards the beginning of the
//onCreate() method
final String mName = getIntent().getStringExtra(USER_NAME_MERCURY);
