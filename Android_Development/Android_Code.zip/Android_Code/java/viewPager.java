//relavant code is starred

public class ArticlePagerActivity extends AppCompatActivity{

    private static final String EXTRA_ARTICLE_ID = "com.bignerdranch.android.project2.article_id";

    private ViewPager mViewPager; //********************
    private List<Article> mArticles;

    public static Intent newIntent(Context packageContext, UUID articleId){
        Intent intent = new Intent(packageContext, ArticlePagerActivity.class);
        intent.putExtra(EXTRA_ARTICLE_ID, articleId);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_pager);//********************

        UUID articleId = (UUID) getIntent().getSerializableExtra(EXTRA_ARTICLE_ID);

        mViewPager = findViewById(R.id.article_view_pager);//********************

        try {
            mArticles = ScienceArticles.get(this).getArticles();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //creating the FragmentStatePagerAdapter requires the FragmentManager. FragmentStatePagerAdapter
        //is your agent managing the conversation with ViewPager which is why you need FragmentManager.
        //what exactly is FragmentStatePagerAdapter doing? It is adding the fragments you return to
        //your activity and helping ViewPager identify the fragments' views so that they can be placed
        //correctly.
        //the following line gets the Activity's instance of FragmentManager
        FragmentManager fragmentManager = getSupportFragmentManager();//********************
        //********************
        mViewPager.setAdapter(new FragmentStatePagerAdapter(fragmentManager) { //sets the adapter to be an unnamed instance of FragmentStatePagerAdapter

          //this is where the magic happens. Here, we fetch the Article instance for the given
          //position in the data set. Then, it uses that Article's ID to create and return a properly
          //configured ArticleFragment
            @Override
            public Fragment getItem(int position) {
                Article article = mArticles.get(position);
                return ArticleFragment.newInstance(article.getUuid());
            }

            @Override
            public int getCount() {
                return mArticles.size();
            }
        });

        //********************
        //starts the ViewPager at the Article you selected
        for(int i = 0; i < mArticles.size(); i++){
            if(mArticles.get(i).getUuid().equals(articleId)){
                mViewPager.setCurrentItem(i);
                break;
            }
        }
    }
}
