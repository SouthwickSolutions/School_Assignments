//this method is called when the user presses the back button from CheatActivity.
//The request code is from startActivityForResult from above
//The resultCode is one of two predefined constants: RESULT_OK or RESULT_CANCELLED.
//Setting result codes is useful when the parent needs to take different action
//depending on how the child activity finished

protected void onActivityResult(int requestCode, int resultCode, Intent data){
    if(resultCode != Activity.RESULT_OK){
        return;
    }
    if(requestCode == REQUEST_CODE_CHEAT){  //if the back button was hit from the CheatActivity...
        if(data == null){
            return;
        }
    }
    ...
}

//the following is in the Activity that will be sending data back to the previous
//activity and demostrates setResult which is what the previous activity is
//interested in
private void setAnswerShownResult(boolean isAnswerShown){
    Intent data = new Intent();
    data.putExtra(EXTRA_ANSWER_SHOWN, isAnswerShown);
    setResult(RESULT_OK, data);
}
