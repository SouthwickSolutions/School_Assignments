//saves data across a runtime configuration change, like screen rotation

@Override
public void onSaveInstanceState(Bundle savedInstanceState){
    super.onSaveInstanceState(savedInstanceState);
    //the following demonstrates a Bundle in action. It's storing the index of
    //the question that the user is on 
    savedInstanceState.putInt(KEY_INDEX, mCurrentIndex);
}
