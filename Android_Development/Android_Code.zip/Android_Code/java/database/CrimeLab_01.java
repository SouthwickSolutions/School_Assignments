package com.bignerdranch.android.criminalintent;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.bignerdranch.android.criminalintent.database.CrimeCursorWrapper;
import com.bignerdranch.android.criminalintent.database.CrimeDbSchema.CrimeTable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

//***FOURTH POINT***
//singleton
//This class is a centralized stash for Crime objects
public class CrimeLab {
    public static CrimeLab sCrimeLab;

    private Context mContext;
    private SQLiteDatabase mDatabase;

    //this get method is what make a singleton a singleton. It checks to see if there is already an
    //instance of CrimeLab. If there is, it returns that instance. If there isn't, this is where it
    //creates the single instance
    public static CrimeLab get(Context context){
        if(sCrimeLab == null){
            sCrimeLab = new CrimeLab(context);
        }
        return sCrimeLab;
    }

    //this is the constructor of the class. Note that it is private so nobody can bypass the get()
    //method
    private CrimeLab(Context context){
        mContext = context.getApplicationContext();
        //calling getWritableDatabase() does the following:
        //1.) open crimeBase.db
        //2.) calls onCreate(SQLiteDatabase) if this is the first time
        //3.) checks the version (if this isnt the first time). Calls onUpgrade(SQLiteDatabase, int, int)
        mDatabase = new CrimeBaseHelper(mContext).getWritableDatabase();
            }

    public void addCrime(Crime c){
        ContentValues values = getContentValues(c); //used to put a Crime in the database

        //inserts into the database
        mDatabase.insert(CrimeTable.NAME, null, values);
    }

    public List<Crime> getCrimes(){ //returns all crimes and puts them in a list
        List<Crime> crimes = new ArrayList<>();

        //gets all crimes. Null means all values in this case
        CrimeCursorWrapper cursor = queryCrimes(null, null);

        try{
            cursor.moveToFirst();
            while(!cursor.isAfterLast()){
                crimes.add(cursor.getCrime());//gets the individual crime
                cursor.moveToNext();
            }
        }finally{
            cursor.close();
        }
        return crimes;
    }

    //not to be confused with CrimeCursorWrapper.getCrime
    public Crime getCrime(UUID id){ //returns a crime with the given ID
        CrimeCursorWrapper cursor = queryCrimes(
                CrimeTable.Cols.UUID + " = ?",
                new String[]{id.toString()}
        );

        try{
            if(cursor.getCount() == 0){
                return null;
            }

            cursor.moveToFirst();
            return cursor.getCrime();
        }finally {
            cursor.close();
        }
    }

    //updates the database
    public void updateCrime(Crime crime){
        String uuidString = crime.getId().toString();
        ContentValues values = getContentValues(crime);

        mDatabase.update(CrimeTable.NAME, values,
                CrimeTable.Cols.UUID + " = ? ",
                new String[] {uuidString});
    }

    //queries the databasse
    private CrimeCursorWrapper queryCrimes(String whereClause, String[] whereArgs){
        Cursor cursor = mDatabase.query(
                CrimeTable.NAME,
                null, //selects all columns
                whereClause,
                whereArgs,
                null, //groupBy
                null, //having
                null //orderBy
        );
        return new CrimeCursorWrapper(cursor);
    }

    //takes care of shuttling a Crime into ContentValues class
    private static ContentValues getContentValues(Crime crime){
        ContentValues values = new ContentValues();

        values.put(CrimeTable.Cols.UUID, crime.getId().toString());
        values.put(CrimeTable.Cols.TITLE, crime.getTitle());
        values.put(CrimeTable.Cols.DATE, crime.getDate().getTime());
        values.put(CrimeTable.Cols.SOLVED, crime.isSolved() ? 1 : 0);

        return values;
    }
}
