package com.bignerdranch.android.criminalintent.database;

//all of the inner classes makes it safer to update your program if you ever need to change the name
//of the column or add additional data to the table
public class CrimeDbSchema {

    //this class only exists to define the String constants needed to describe the moving pieces of
    //your table definition
    public static final class CrimeTable{
        public static final String NAME = "crimes";

        public static final class Cols{
            public static final String UUID = "uuid";
            public static final String TITLE = "title";
            public static final String DATE =  "date";
            public static final String SOLVED = "solved";
        }
    }
}
