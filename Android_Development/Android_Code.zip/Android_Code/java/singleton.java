//a singleton is a class that allows only one instance of itself to be created.
//a singleton exists as long as the application stays in memory, so storing the
//list in a singleton will keep the crime data available throughout any lifecycle
//changes in your activities and fragments.
//they will be destroyed when android removes your application from memory

//To create a singleton, you create a class with a private constructor and a
//get() method.
//if the instance already exists, then get() simply returns the instance and if
//the instance does not yet exist, then get() will call the constructor to
//create it

//putting an s in front of a member name (sCrimeLab) is an android convention
//that makes it clear it is a static variable.
//notice that the private constructor makes it where other classes will not be
//able to create a CrimeLab bypassing the get() method

public class CrimeLab {
    public static CrimeLab sCrimeLab;

    private Context mContext;
    private SQLiteDatabase mDatabase;

    //this get method is what make a singleton a singleton. It checks to see if there is already an
    //instance of CrimeLab. If there is, it returns that instance. If there isn't, this is where it
    //creates the single instance
    public static CrimeLab get(Context context){
        if(sCrimeLab == null){
            sCrimeLab = new CrimeLab(context);
        }
        return sCrimeLab;
    }

    //this is the constructor of the class. Note that it is private so nobody can bypass the get()
    //method
    private CrimeLab(Context context){
        mContext = context.getApplicationContext();
        //calling getWritableDatabase() does the following:
        //1.) open crimeBase.db
        //2.) calls onCreate(SQLiteDatabase) if this is the first time
        //3.) checks the version (if this isnt the first time). Calls onUpgrade(SQLiteDatabase, int, int)
        mDatabase = new CrimeBaseHelper(mContext).getWritableDatabase();
            }
