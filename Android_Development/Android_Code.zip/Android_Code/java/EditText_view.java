//class memeber
mEnterName = (EditText) findViewById(R.id.splash_enter_name);

//this code demostrates what happens when you click on a button, but pay attention
//to the "String name" line. This takes the text from the EditText view and
//converts it to a string. Then it is passed to the other activity and stored
//as an extra
mGetStartedButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        String name = mEnterName.getText().toString(); //***important demonstration
        Intent intent = MainActivity.newIntent(SplashActivity.this, name);
        startActivity(intent);
    }
});



//in the other activity, to call the text that was entered, you use the following
//code.
//Note that USER_NAME_MAIN was used as the key when the data was put in as an
//extra inside of the newIntent method
//This code would be put in the same activity that has the newIntent method
String mName = getIntent().getStringExtra(USER_NAME_MAIN);
