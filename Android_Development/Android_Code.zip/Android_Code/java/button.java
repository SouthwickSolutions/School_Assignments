private Button mTrueButton; //class variable

//inside onCreate
mTrueButton = (Button) findViewById(R.id.true_button);
mTrueButton.setOnClickListener(new View.OnClickListener(){
    @Override
    public void onClick(View v){
      ...
    }
});
